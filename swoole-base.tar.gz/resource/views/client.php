<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SSE Client</title>
</head>
<body>
<h1>Server-Sent Events Client</h1>
<div id="messages">.</div>

<script>
    function parseJson(jsonString) {
        jsonString = jsonString.replace(/^\s+|\s+$/g, '');

        try {
            return JSON.parse(jsonString);
        } catch (e) {
            return null;
        }
    }

    const eventSource = new EventSource("http://192.168.56.55:9505");
    // const eventSource = new EventSource("http://127.0.0.1:9505");
    // const eventSource = new EventSource("http://172.25.0.10:9505");

    eventSource.onmessage = function(event) {
        // const data = event.data;
        const data = /^\s*\#(.+)/.exec(event.data);
        if (data) {
            console.log('SSE messages: ' + data[1]);
        } else {
            const json = parseJson(event.data);

            if (json) {
                document.querySelector('#messages').innerHTML += json.policy;
            } else {
                console.log('sse ', event);
            }
        }
    };

    eventSource.onopen = function() {
        console.log("SSE connection opened.");
    };

    eventSource.onerror = function() {
        console.log("SSE connection error.");
    };
</script>
</body>
</html>
