<?php
/**
 * @var SwooleBase\Foundation\Console $console
 */

$console = require __DIR__.'/../src/bootstrap.php';

$console->run();
