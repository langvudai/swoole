<?php

namespace Src\Command;

use Src\Api\Repositories\Client\ClientRepository;
use Src\Api\Repositories\Client\ClientRepositoryInterface;
use Src\Api\Services\ClientService;
use SwooleBase\Foundation\Abstracts\BackgroundWorker;
use SwooleBase\Foundation\DI;
use function SwooleBase\Foundation\console;

/**
 * Class ExampleBackgroundWorkCommand
 * @package Src\Command
 */
class ExampleBackgroundWorkCommand extends BackgroundWorker
{
    protected static $storage_path = '/var/www/storage/app/serializes';

    function main(ClientService $service)
    {
        print_r($service->getById($this->getArgument('client_id')));
    }

    public function middleware(DI $di): void
    {
        $di->bind(ClientRepositoryInterface::class, ClientRepository::class);
    }
}
