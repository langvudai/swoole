<?php

namespace Src\Entities;

use Src\Database\DbTable;

class Client extends DbTable
{
    protected $table = 'clients';
}
