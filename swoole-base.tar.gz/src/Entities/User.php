<?php

namespace Src\Entities;

use Src\Database\DbTable;

/**
 * Class User
 * @package Src\Entities
 *
 * @property int $id
 * @property string $uuid
 * @property string $username
 * @property string $password
 * @property int role_authority
 * @property string $remember_token
 *
 * @method static findUsername($value, string $column = '*')
 * @method static findUuid($value, string $column = '*')
 */
final class User extends DbTable
{
    protected $table = 'users';

}
