<?php

namespace Src\Store;

use SwooleBase\Foundation\Abstracts\Storable;

/**
 * Class ClientStore
 * @package Src\Store
 *
 * @method static array all(string $key, callable $callback)
 */
class ClientStore extends Storable
{
    private $actions = [];

    private $warehouse = [];

    public function __construct()
    {
        $this->actions['all'] = function (string $key, callable $callback): ?array {
            if (!isset($this->warehouse[$key]) || !is_array($this->warehouse[$key])) {
                $this->warehouse[$key] = $callback();
            }

            return $this->warehouse[$key];
        };
    }

    public function __call(string $action, array $arguments): mixed
    {
        if (isset($this->actions[$action])) {
            return call_user_func_array($this->actions[$action], $arguments);
        }

        return null;
    }

    public function __get(string $name)
    {
        // TODO: Implement __get() method.
    }
}
