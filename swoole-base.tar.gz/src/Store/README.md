####example 

```php
<?php

namespace Src\Store;

use SwooleBase\Foundation\Interfaces\Auth as AuthFacade;
use SwooleBase\Foundation\Interfaces\Storable;

class Auth implements Storable, AuthFacade
{

    public function action(string $name, callable $callback, bool $overwrite = false)
    {
        // TODO: Implement action() method.
    }

    public function __call(string $action, array $arguments): mixed
    {
        // TODO: Implement __call() method.
    }

    public function __get(string $name)
    {
        // TODO: Implement __get() method.
    }

    public function getId(): int
    {
        // TODO: Implement getId() method.
    }

    public function getAuthority(): int
    {
        // TODO: Implement getAuthority() method.
    }

    public function isAble(int $action, array $arg): bool
    {
        // TODO: Implement isAble() method.
    }

    public function isPrivilege(): bool
    {
        // TODO: Implement isPrivilege() method.
    }

    public function toArray(): array
    {
        // TODO: Implement toArray() method.
    }
}

```