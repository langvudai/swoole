<?php

namespace Src\Middleware;

use SwooleBase\Foundation\Http\Response;
use SwooleBase\Foundation\MiddlewareHandler;
use SwooleBase\Foundation\Http\Request;

use function SwooleBase\Foundation\console;

class LoadServiceProvider
{
    private static $loaded = [];

    public function __construct(Request $request, Response $response, MiddlewareHandler $middleware_handler)
    {
        if (preg_match('/^(https?:\/\/[^\/]+)?\/*api\/((?!api)[\w\-]+)\/?/i', $request->getUri(), $matches)) {
            /** @var \SwooleBase\Foundation\Console $console */
            $console = console();
            $scope = pascal_case($matches[2]);
            $provider_dir = $console->baseApplicationPath("$scope/Providers");

            if (!is_dir($provider_dir)) {
                $scope = 'Api';
                $provider_dir = $console->baseApplicationPath("$scope/Providers");
            }

            if (!is_dir($provider_dir)) {
                return;
            }

            if (isset(self::$loaded[$scope])) {
                return;
            } else {
                self::$loaded[$scope] = [];
            }

            foreach (glob("$provider_dir/*ServiceProvider.php") as $file) {
                $provider = $console->className($scope .'\\Providers\\'. pathinfo($file, PATHINFO_FILENAME));

                if (!in_array($provider, self::$loaded[$scope])) {
                    if (null !== $middleware_handler->handle($provider)) {
                        self::$loaded[$scope][] = $provider;
                    }
                }
            }
        }
    }
}
