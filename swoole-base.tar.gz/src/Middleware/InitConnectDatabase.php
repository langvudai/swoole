<?php

namespace Src\Middleware;

use Src\Database\Connection;
use SwooleBase\Foundation\DI;
use SwooleBase\Foundation\Exception;

class InitConnectDatabase
{
    public function __construct(private DI $DI)
    {
        $connection = Connection::createConnection(Connection::POSTGRESQL);

        if (!$connection) {
            throw new Exception('Error connect database');
        }

        $this->DI->instance(Connection::class, $connection);
    }

    public function terminal()
    {
        /** @var Connection $connection */
        $this->DI->escape(Connection::class);
    }
}
