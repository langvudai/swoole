<?php

namespace Src\Middleware;

use Src\Database\Entities\User as UserEntity;
use SwooleBase\Foundation\DI;
use SwooleBase\Foundation\Http\Request;
use SwooleBase\Foundation\Http\Response;
use SwooleBase\Foundation\Exception;

class AuthenticateRoute
{
    public function handle(Request $request, Response $response, DI $di, UserEntity $user_entity)
    {
        try {
            [$algo, $key, $info, $header, $payload, $signature] = self::verifyToken($request);

            $uuid = $info['uuid'] ?? '';
            /** @var null|UserEntity $user */
            $user = $user_entity->findUuid($uuid);

            if (!$user) {
                throw new \Exception('not user');
            }

            $jwt_secret = $user->secret ?? $key;

            if ($signature !== hash_hmac($algo, "$header.$payload", $jwt_secret)) {
                throw new \Exception('unauthorized');
            }

            $client = $user_entity->getConnection()->find('clients', 'code', $info['client'] ?? '');

            if (is_array($client)) {
                $di->setFactory(strtoupper($info['client'] ?? ''));
                $di->instance(Authentication::class, new Authentication($user, $client));
            } else {
                $di->instance(Authentication::class, new Authentication($user));
            }
        } catch (\Throwable $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * @param $request
     * @return array
     * @throws \Exception
     */
    public static function verifyToken($request): array
    {
        try {
            /** @var Request $request */
            $bearer = $request->get('bearer') ?? $request->getHeaders('authorization') ?? '';

            if (!$bearer) {
                throw new \Exception('token fail.');
            }

            [$header_str, $payload, $signature] = array_pad(explode('.', preg_replace('/^bearer\s+/i', '', $bearer) ), 3, '');
            $header = json_decode(base64_url_decode($header_str), true);
            [$key, $time] = array_pad(explode('.', $header['key'] ?? ''), 2, 0);
            $algo = $header['algo'] ?? '';
            $addr = $header['addr'] ?? '';

            if (!$algo) {
                throw new \Exception('token fail.');
            }

            if (time() > $time) {
                throw new \Exception('token fail. TIME');
            }

            if (!$addr || $request->server('REMOTE_ADDR') !== $addr) {
                throw new \Exception('token fail. REMOTE_ADDR');
            }

            $info = json_decode(base64_url_decode($payload), true);

            return [$algo, $key, $info, $header_str, $payload, $signature];
        } catch (\Throwable $exception) {
            throw new \Exception($exception->getMessage());
        }
    }

}
