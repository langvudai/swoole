<?php

namespace Src\Api\Controllers;

use Src\Api\Requests\LoginRequest;
use Src\Database\Entities\User as UserEntity;
use Src\Middleware\AuthenticateRoute;
use SwooleBase\Foundation\Http\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class AuthController
 * @package Src\Controllers\Api
 *
 */
class AuthController
{
    const TIME_LIFE = 3600;

    /**
     * @param LoginRequest $request
     * @param UserEntity $user_entity
     * @return JsonResponse
     * @throws \SwooleBase\Foundation\Exception
     * @throws \Exception
     */
    public function login(LoginRequest $request, UserEntity $user_entity): JsonResponse
    {
        $request->throwJsonIfFailed();
        // password_hash('123456', PASSWORD_DEFAULT);
        $username = $request->get('username');
        $password = $request->get('password');
        /** @var null|UserEntity $user */
        $user = $user_entity->findUsername($username);

        if (!$user) {
            return symfony_json_response(false, [], 'Tên đăng nhập không chính xác', 401);
        }

        if (!password_verify($password, $user->password)) {
            return symfony_json_response(false, [], 'Mật khẩu đăng nhập không chính xác', 401);
        }

        $algo = 'sha256';
        $key = bin2hex(random_bytes(16)); // 32 char
        $time = time() + self::TIME_LIFE;
        $header = base64_url_encode(json_encode(['algo' => $algo, 'key' => "$key.$time", 'addr' => $request->server('REMOTE_ADDR')]));
        $payload = base64_url_encode(json_encode([
            'uuid' => $user->uuid,
            'client' => $request->get('client'),
        ]));
        $jwt_secret = $user->secret ?? $key;
        $signature = hash_hmac($algo, "$header.$payload", $jwt_secret);

        return symfony_json_response(true, "$header.$payload.$signature");
    }

    public function refreshToken(Request $request, UserEntity $user_entity): JsonResponse
    {
        try {
            [$algo, $key, $info, $header, $payload, $signature] = AuthenticateRoute::verifyToken($request);
        } catch (\Throwable $exception) {
            return symfony_json_response(false, null, $exception->getMessage());
        }

        $uuid = $info['uuid'] ?? '';
        /** @var null|UserEntity $user */
        $user = $user_entity->findUuid($uuid);

        if (!$user) {
            return symfony_json_response(false, null, 'not user');
        }

        $jwt_secret = $user->secret ?? $key;

        if ($signature !== hash_hmac($algo, "$header.$payload", $jwt_secret)) {
            return symfony_json_response(false, null, 'unauthorized');
        }

        $time = time() + self::TIME_LIFE;
        $header = base64_url_encode(json_encode(['algo' => $algo, 'key' => "$key.$time", 'addr' => $request->server('REMOTE_ADDR')]));
        $signature = hash_hmac($algo, "$header.$payload", $jwt_secret);

        return symfony_json_response(true, "$header.$payload.$signature");
    }
}
