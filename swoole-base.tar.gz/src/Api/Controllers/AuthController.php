<?php

namespace Src\Api\Controllers;

use Src\Api\Requests\LoginRequest;
use Src\Entities\User as UserEntity;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class AuthController
 * @package Src\Controllers\Api
 *
 */
class AuthController
{
    const TIME_LIFE = 3600;

    /**
     * @param LoginRequest $request
     * @return JsonResponse
     * @throws \SwooleBase\Foundation\Exception
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $request->throwJsonIfFailed();
        // password_hash('123456', PASSWORD_DEFAULT);
        $username = $request->get('username');
        $password = $request->get('password');
        /** @var null|UserEntity $user */
        $user = UserEntity::findUsername($username);

        if (!$user) {
            return symfony_json_response(false, [], 'Tên đăng nhập không chính xác', 401);
        }

        if (!password_verify($password, $user->password)) {
            return symfony_json_response(false, [], 'Mật khẩu đăng nhập không chính xác', 401);
        }

        $jwt_secret = 'abcdef';
        $key = rand(0, 1000);
        $algo = 'sha256';
        $time = time() + self::TIME_LIFE;
        $type = 'bearer';
        $header = base64_url_encode(json_encode(compact('algo', 'key', 'time', 'type')));
        $payload = base64_url_encode(json_encode([
            'uuid' => $user->uuid,
            'client' => $request->get('client'),
        ]));
        $signature = hash_hmac($algo, "$key.$payload", $jwt_secret);

        return symfony_json_response(true, "$header.$payload.$signature");
    }
}
