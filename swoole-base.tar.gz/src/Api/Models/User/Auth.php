<?php

namespace Src\Api\Models\User;

use Src\Shared\Entities\User;
use SwooleBase\Foundation\Abstracts\Json;

class Auth extends Json
{
    private null|User $user;

    public function __construct(User $user = null)
    {
        $this->user = $user;
    }

    public function getId(): int
    {
        return 0;
    }

    public function getAuthority(): int
    {
        return 0;
    }

    public function isAble(int $action, array $arg): bool
    {
        return false;
    }

    public function isPrivilege(): bool
    {
        return false;
    }

    public function toArray(): array
    {
        return [];
    }
}
