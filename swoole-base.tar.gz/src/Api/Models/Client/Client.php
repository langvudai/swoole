<?php

namespace Src\Api\Models\Client;

use SwooleBase\Foundation\Abstracts\Json;

class Client extends Json
{
    protected array $hidden = [
        'updated_at',
        'deleted_time',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected array $dates = ['created_at'];

    protected string $date_format = 'd/m/Y';

    public function __construct(array $data)
    {
        $this->data = $data;
    }
}
