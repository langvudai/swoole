<?php

namespace Src\Api\Providers;

use Src\Api\Repositories\Client\ClientRepository;
use Src\Api\Repositories\Client\ClientRepositoryInterface;
use SwooleBase\Foundation\DI;

class RepositoryServiceProvider
{
    public function __construct(DI $di)
    {
        $di->bind(ClientRepositoryInterface::class, ClientRepository::class);
    }
}
