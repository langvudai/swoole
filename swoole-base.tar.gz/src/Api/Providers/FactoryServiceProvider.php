<?php

namespace Src\Api\Providers;

use Src\Api\Services\ClientPolicyService;
use SwooleBase\Foundation\DI;
use function SwooleBase\Foundation\console;

/**
 * Class FactoryServiceProvider
 * @package Src\Api\Providers
 */
class FactoryServiceProvider
{
    public function __construct(DI $di)
    {
        $bindings = console(DI::class, '$bindings');

        console(DI::class, '$bindings', array_replace_recursive($bindings, [
            ClientPolicyService::class => [
                'CLIENT1' => \Src\Api\Factories\CLIENT1\Services\ClientPolicyService::class,
                'CLIENT2' => \Src\Api\Factories\CLIENT2\Services\ClientPolicyService::class,
            ]
        ]));
    }
}
