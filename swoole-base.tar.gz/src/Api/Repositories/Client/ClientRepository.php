<?php

namespace Src\Api\Repositories\Client;

use Src\Api\Models\Client\Client;
use Src\Entities\Client as ClientEntity;
use Src\Store\ClientStore;

class ClientRepository implements ClientRepositoryInterface
{
    public function getAll(): array
    {
        return ClientStore::all('123456', function () {
            $result = ClientEntity::PDO()->statement('select * from clients');

            if (!is_array($result)) {
                return null;
            }

            return array_map(fn ($v) => new Client($v), $result);
        });
    }

    public function getById(int $id): Client
    {
        /** @var null|ClientEntity $client */
        $client = ClientEntity::find($id);

        return new Client($client ? $client->all() : []);
    }
}
