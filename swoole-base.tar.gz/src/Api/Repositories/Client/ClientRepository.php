<?php

namespace Src\Api\Repositories\Client;

use Src\Api\Models\Client\Client;
use Src\Database\Connection;
use Src\Store\ClientStore;

class ClientRepository
{
    public function __construct(
        private Connection $connection
    ) {}

    public function getAll(): array
    {
        return ClientStore::all('123456', function () {
            $recordset = $this->connection->table('clients')->get();
            $recordset->setModel(Client::class);
            return $recordset->toArray();
        });
    }

    public function getById(int $id): Client
    {
        $client = $this->connection->find('clients', 'id', $id);

        return new Client($client ?? []);
    }
}
