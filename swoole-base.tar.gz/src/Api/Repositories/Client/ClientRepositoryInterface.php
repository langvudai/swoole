<?php

namespace Src\Api\Repositories\Client;

use Src\Api\Models\Client\Client;

interface ClientRepositoryInterface
{
    /**
     * Get all
     * @return array
     */
    public function getAll(): array;

    /**
     * Get client by id
     * @param int $id
     * @return Client
     */
    public function getById(int $id): Client;

}
