<?php

namespace Src\Api\Services;

interface ClientPolicyService
{
    /**
     * @return array
     */
    public function getPolicy(): array;
}
