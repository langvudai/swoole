<?php

namespace Src\Api\Requests;

use SwooleBase\Foundation\Abstracts\Validator;

class LoginRequest extends Validator
{
    public function rules(array $input): array
    {
        return [
            'username' => [
                function ($value, $result_middleware) {
                    if (!$value) {
                        return [false, 'required'];
                    }
                    return [true];
                }
            ],
            'password' => [
                ['/^.{6,}$/', ':attribute lon hon 6 ky tu'],
            ],
        ];
    }

    public function attributes(): array
    {
        return [
            'userna1me' => 'ten dang nhap'
        ];
    }
}
