<?php

namespace SwooleBase\Foundation\Interfaces;

interface IsStronglyClass
{
    public function assert(): array;
}