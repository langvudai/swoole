<?php

namespace Src\Web\Controllers;

use SwooleBase\Foundation\Http\LoadHTML;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class IndexController
{
    public function index()
    {
        return new LoadHTML('index', ['content' => 'Hello world']);
    }

    public function download()
    {
        $filePath = '/var/www/storage/app/tmp/abc.download';
        $file = new BinaryFileResponse($filePath);
        $file->headers->set('Content-Disposition', 'attachment; filename="abc.download"');
        return $file;
    }
}