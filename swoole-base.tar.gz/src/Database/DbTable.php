<?php

namespace Src\Database;

use SwooleBase\Foundation\Exception;

/**
 * Class DbTable
 * @package Foundation\Database
 *
 * @method static mixed find($value, string $column = '*')
 * @method static mixed create(array $attributes, string $primary_key = 'id')
 * @method static false|int whereUpdate(string $where_column, $where_value, array $attributes)
 * @method static mixed whereDelete(string $where_column, $where_value)
 */
abstract class DbTable
{
    protected $pdo;

    protected $table;

    protected $result;

    protected $connection = PDO::POSTGRESQL;

    public function __construct()
    {
        $this->pdo = PDO::createOrReceive($this->connection);
    }

    /**
     * @param string $name
     * @return mixed
     */
    public function __get(string $name)
    {
        if ($this->result && is_array($this->result)) {
            return $this->result[$name] ?? null;
        }

        return null;
    }

    public function all()
    {
        return $this->result;
    }

    /**
     * @param string $name
     * @param array $arguments
     * @return null
     * @throws \Exception
     */
    public static function __callStatic(string $name, array $arguments)
    {
        $method = null;

        if (preg_match('/^find([A-Z]\w+)?$/', $name, $matches)) {
            $method = 'find';
            $first = (isset($matches[1]) && $matches[1]) ? lcfirst($matches[1]) : null;
            array_unshift($arguments, $first);
        } elseif (preg_match('/^where(Update|Delete)$/', $name, $matches)) {
            $method = lcfirst($matches[1]);
        } elseif ('create' === strtolower($name)) {
            $method = 'create';
        }

        if ($method) {
            $obj = new static();
            if (method_exists($obj->getPDO(), $method)) {
                array_unshift($arguments, $obj->getTable());
                $result = call_user_func_array([$obj->getPDO(), $method], $arguments);

                if (is_array($result)) {
                    $obj->result = $result;
                    return $obj;
                }

                return $result;
            }
        }

        return null;
    }

    /**
     * @return PDO
     * @throws Exception
     */
    public function getPDO(): PDO
    {
        if (null === $this->pdo) {
            throw new Exception('PDO not created');
        }

        return $this->pdo;
    }

    /**
     * @return string
     */
    public function getTable(): string
    {
        return $this->table;
    }

    /**
     * @return PDO
     * @throws Exception
     */
    public static function PDO(): PDO
    {
        return (new static())->getPDO();
    }
}
