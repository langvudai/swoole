<?php

namespace Src\Database;

use Src\Database\Postgres\Driver;
use Src\Database\Postgres\QueryBuilder;
use SwooleBase\Foundation\Abstracts\Json;
use SwooleBase\Foundation\DI;
use SwooleBase\Foundation\Exception;

/**
 * Class DbTable
 * @package Foundation\Database
 *
 * @method static mixed find($value, string $column = '*')
 * @method static mixed create(array $attributes, string $primary_key = 'id')
 * @method static false|int whereUpdate(string $where_column, $where_value, array $attributes)
 * @method static mixed whereDelete(string $where_column, $where_value)
 */
abstract class DbTable extends Json
{
    protected $connection;

    protected $table;

    protected $attributes;

    protected $connection_name = Connection::class;

    protected static $deleted_timestamp_column = null;

    protected static $deleted_by_column = null;

    protected static $primary_key = 'id';

    public function __construct(DI $DI, array $attributes = null)
    {
        $this->connection = $DI->make($this->connection_name);
        $this->attributes = $attributes;
    }

    /**
     * @param string $name
     * @return mixed
     */
    public function __get(string $name)
    {
        if ($this->attributes && is_array($this->attributes)) {
            return $this->attributes[$name] ?? null;
        }

        return null;
    }

    /**
     * @return array|null
     */
    public function all(): ?array
    {
        return $this->attributes;
    }

    /**
     * @param string $table_name
     * @return QueryBuilderInterface|null
     */
    public static function query(string $table_name): ?QueryBuilderInterface
    {
        if (static::class === DbTable::class) {
            $connection = Connection::createOrReceive();

            return match (get_class($connection)) {
                Driver::class => (new QueryBuilder($connection))->table($table_name),
                default => null
            };
        }

        $obj = (new static())->queryBuilder();
        return $obj ? $obj->table($table_name) : null;
    }

    /**
     * @param string $name
     * @param array $arguments
     * @return null
     * @throws \Exception
     */
    public function __call(string $name, array $arguments)
    {
        $method = null;

        if (preg_match('/^find([A-Z]\w+)?$/', $name, $matches)) {
            $method = 'find';
            $first = (isset($matches[1]) && $matches[1]) ? lcfirst($matches[1]) : null;
            array_unshift($arguments, $first ?? self::$primary_key);
        } elseif (preg_match('/^where(Update|Delete)$/', $name, $matches)) {
            $method = lcfirst($matches[1]);
        } elseif ('create' === strtolower($name)) {
            $method = 'create';
        }

        if ($method) {
            if (method_exists($this->getConnection(), $method)) {
                array_unshift($arguments, $this->getTable());
                $result = call_user_func_array([$this->getConnection(), $method], $arguments);

                if ('find' === $method && is_array($result) && !empty($result)) {
                    $this->attributes = $result;
                    return $this;
                }

                return $result;
            }
        }

        return null;
    }

    /**
     * @return Connection
     * @throws Exception
     */
    public function getConnection(): Connection
    {
        if (null === $this->connection) {
            throw new Exception('Connection not created');
        }

        return $this->connection;
    }

    /**
     * @return string
     */
    public function getTable(): string
    {
        return $this->table;
    }

    /**
     * @return QueryBuilderInterface|null
     */
    public function queryBuilder(): ?QueryBuilderInterface
    {
        return match (get_class($this->connection)) {
            Driver::class => new QueryBuilder($this->connection, $this),
            default => null,
        };
    }

    public final function jsonSerialize(): mixed
    {
        return $this->attributes && is_array($this->attributes) ? $this->attributes : [];
    }

    /**
     * @param null $user_id
     * @return bool
     */
    public function delete($user_id = null): bool
    {
        if (!self::$deleted_timestamp_column) {
            return false;
        }

        $attributes = [self::$deleted_timestamp_column => time()];

        if (self::$deleted_by_column && $user_id) {
            $attributes[self::$deleted_by_column] = $user_id;
        }

        return (bool)self::whereUpdate(self::$primary_key, $this->attributes[self::$primary_key], $attributes);
    }
}
