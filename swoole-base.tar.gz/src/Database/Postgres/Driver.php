<?php

namespace Src\Database\Postgres;

use Exception;
use PDO;
use PDOException;

class Driver extends \Src\Database\PDO
{
    /** @var PDO */
    private $pdo;

    /** @var null|int */
    protected $row_count = null;

    /** @var bool */
    protected $in_transaction = false;

    /**
     * Postgres constructor.
     * @param array $cfg
     */
    public function __construct(array $cfg)
    {
        try {
            $dsn = sprintf('pgsql:host=%s;port=%s;dbname=%s;user=%s;password=%s', $cfg['HOST'], $cfg['PORT'], $cfg['DATABASE'], $cfg['USERNAME'], $cfg['PASSWORD']);
            $this->pdo = new PDO($dsn);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            if ($cfg['SCHEMA']) {
                $this->pdo->exec(sprintf('SET search_path TO %s', $cfg['SCHEMA']));
            }

            if ($cfg['TIMEZONE']) {
                $this->pdo->exec(sprintf('SET TIME ZONE \'%s\'', $cfg['TIMEZONE']));
            }

        } catch (PDOException $e) {
            exit("\033[31m{$e->getMessage()}\033[0m\n{$e->getTraceAsString()}");
        }
    }

    public function getConnection()
    {

    }

    /**
     * @param $sql
     * @return array
     */
    public function query(string $sql): array
    {
        $result = $this->pdo->query($sql);

        if (!$result) {
            $errorInfo = $this->pdo->errorInfo();
            $errorCode = $this->pdo->errorCode();
            throw new PDOException(vsprintf('SQLSTATE:%s'.PHP_EOL.', Driver:%s, Message:%s', $errorInfo), $errorCode);
        }

        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * @param string $sql
     * @param array $binds
     * @return mixed
     */
    public function statement(string $sql, array $binds = []): mixed
    {
        $stmt = $this->pdo->prepare($sql);
        $this->row_count = null;

        if (!$stmt) {
            $errorInfo = $this->pdo->errorInfo();
            $errorCode = $this->pdo->errorCode();

            throw new PDOException(vsprintf('SQLSTATE:%s'.PHP_EOL.', Driver:%s, Message:%s', $errorInfo), $errorCode);
        }

        if (!preg_match('/^\s*select\s+/i', $sql)) {
            if (!empty($binds)) {
                $binds = array_filter($binds, fn($v) => is_scalar($v));
            } else {
                $binds = null;
            }

            if ($stmt->execute($binds)) {
                $this->row_count = $stmt->rowCount();
                return true;
            }

            return false;
        }

        // SELECT
        if (!empty($binds)) {
            foreach ($binds as $key => $value) {
                $var = !is_scalar($value) ? null : $value;
                $stmt->bindParam(":$key", $var);
            }
        }

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * @param callable $callback
     * @return mixed
     * @throws Exception
     */
    public function transaction(callable $callback): mixed
    {
        try {
            // start transaction
            if (!$this->in_transaction) {
                $this->pdo->beginTransaction();
                $this->in_transaction = true;
            }

            // execute callback with PDO transaction
            $result = $callback($this->pdo);

            if (false === $result && $this->in_transaction) {
                // rollback transaction
                $this->pdo->rollBack();
                $this->in_transaction = false;
            }

            if ($this->in_transaction) {
                $this->pdo->commit();
                $this->in_transaction = false;
            }

            return $result;
        } catch (PDOException $e) {
            // if error, rollback transaction
            $this->pdo->rollBack();
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @param $table
     * @param string|null $where_column
     * @param $value
     * @param string $select
     * @return mixed
     */
    public function find($table, ?string $where_column, $value, string $select = '*'): mixed
    {
        if (!$table || !is_string($table)) {
            return null;
        }

        if (null === $where_column) {
            $where_column = 'id';
        }

        if ('*' !== trim($select)) {
            $arr = array_map('trim', explode(',', $select));
            $select = implode(',', array_map(fn($col) => $this->escapeColumnName($col), $arr));
        }

        $param = [$where_column => $value];
        $sql = "SELECT {$select} FROM \"{$table}\" WHERE \"{$where_column}\" = :{$where_column}";
        $result = $this->statement($sql, $param);

        if ($result && is_array($result)) {
            return array_shift($result);
        }

        return $result;
    }

    /**
     * @param $table
     * @param array $attributes
     * @param string $primary_key
     * @return mixed
     * @throws Exception
     */
    public function create($table, array $attributes, string $primary_key = 'id'): mixed
    {
        $columns = [];
        $placeholders = [];
        $values = [];
        $id = $this->escapeColumnName($primary_key);

        foreach ($attributes as $column => $value) {
            if ($value !== null) {
                $columns[] = $this->escapeColumnName($column);
                $placeholders[] = ':' . str_replace('"', '', $column);
                $values[str_replace('"', '', $column)] = $value;
            }
        }

        $sql = sprintf('INSERT INTO %s (%s) VALUES (%s) RETURNING %s', $table, implode(', ', $columns), implode(', ', $placeholders), $id);

        return $this->transaction(function ($pdo) use ($sql, $values, $table, $id) {
            /** @var PDO $pdo */
            // insert
            $stmt = $pdo->prepare($sql);
            $stmt->execute($values);
            // get result id
            $new_id = $stmt->fetchColumn();
            // select record
            $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE $id = :id");
            $stmt->bindParam(':id', $new_id);
            $stmt->execute();
            // Fetch to array
            return $stmt->fetch(PDO::FETCH_ASSOC);
        });
    }

    public function update($table, string $where_column, $where_value, array $attributes)
    {
        $values = [];
        $id = $this->escapeColumnName($where_column);
        $placeholder_id = 'valueWhere';
        $set = [];

        foreach ($attributes as $column => $value) {
            if ($value !== null) {
                $col = $this->escapeColumnName($column);
                $placeholder = str_replace('"', '', $column);

                if ($placeholder === $placeholder_id) {
                    $placeholder_id .= 'w';
                }

                $set[] = "$col = :$placeholder";
                $values[str_replace('"', '', $column)] = $value;
            }
        }

        $values[$placeholder_id] = $where_value;

        $sql = sprintf('UPDATE %s SET %s WHERE %s=:%s', $table, implode(', ', $set), $id, $placeholder_id);
        return $this->statement($sql, $values);
    }

    /**
     * @param $table
     * @param string $where_column
     * @param $where_value
     * @return mixed
     */
    public function delete($table, string $where_column, $where_value): mixed
    {
        $sql = sprintf('DELETE FROM %s WHERE %s = :value', $table, $this->escapeColumnName($where_column));
        return $this->statement($sql, ['value' => $where_value]);
    }

        /**
     * @param string $column
     * @return string
     */
    private function escapeColumnName(string $column): string
    {
        return '"' . str_replace('"', '""', $column) . '"';
    }
}
