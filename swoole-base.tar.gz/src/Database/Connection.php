<?php

namespace Src\Database;

use Src\Database\Postgres\Driver;
use Src\Database\Postgres\QueryBuilder;

abstract class Connection
{
    const POSTGRESQL = 'pgsql';

    private static $drivers = [];

    public static function config($connection_name, string $driver, array $config)
    {
        if (!$driver || !class_exists($driver)) {
            return;
        }

        self::$drivers[$connection_name] = ['connection' => [], 'driver' => $driver, 'config' => $config];
    }

    /**
     * @param $connection_name
     * @return Connection|null
     */
    public static function createConnection($connection_name): ?Connection
    {
        $driver = self::$drivers[$connection_name]['driver'];

        if (is_subclass_of($driver, Connection::class)) {
            return new $driver(self::$drivers[$connection_name]['config']);
        }

        return null;
    }

    /**
     * @param string $table_name
     * @return QueryBuilderInterface|null
     */
    public function table(string $table_name): ?QueryBuilderInterface
    {
        return match (get_class($this)) {
            Driver::class => (new QueryBuilder($this))->table($table_name),
            default => null
        };
    }

    abstract public function getDriver();

    /**
     * @param string $sql
     * @param array $binds
     * @return mixed
     */
    abstract public function statement(string $sql, array $binds = []): mixed;

    /**
     * @param callable $callback
     */
    abstract public function transaction(callable $callback);

    abstract public function find($table, ?string $where_column, $value, string $select = '*');

    abstract public function create($table, array $attributes, string $primary_key = 'id');

    abstract public function update($table, string $where_column, $where_value, array $attributes);

    abstract public function delete($table, string $where_column, $where_value);

    abstract public function query(string $sql, array $binds = []): ?RecordsetInterface;
}
