<?php

namespace Src\Database;

abstract class PDO
{
    const POSTGRESQL = 'pgsql';

    private static $drivers = [];

    public static function config($connection_name, string $pdo_class, array $config)
    {
        if (!$pdo_class || !class_exists($pdo_class)) {
            return;
        }

        self::$drivers[$connection_name] = ['pdo' => $pdo_class, 'config' => $config];
    }

    /**
     * @param null $connection_name
     * @return PDO|null
     */
    public static function createOrReceive($connection_name = null): ?PDO
    {
        $connection_name = $connection_name ?? key(self::$drivers);

        if (!$connection_name || !isset(self::$drivers[$connection_name])) {
            return null;
        }

        if (self::$drivers[$connection_name]['pdo'] instanceof PDO) {
            return self::$drivers[$connection_name]['pdo'];
        }

        return self::createPDO($connection_name, self::$drivers[$connection_name]['pdo']);
    }

    /**
     * @param $connection_name
     * @param string $pdo_class
     * @return PDO|null
     */
    private static function createPDO($connection_name, string $pdo_class): ?PDO
    {
        if (is_subclass_of($pdo_class, PDO::class)) {
            self::$drivers[$connection_name]['pdo'] = new $pdo_class(self::$drivers[$connection_name]['config']);
            return self::$drivers[$connection_name]['pdo'];
        }

        return null;
    }

    abstract public function getConnection();

    /**
     * @param string $sql
     * @param array $binds
     * @return mixed
     */
    abstract public function statement(string $sql, array $binds = []): mixed;

    /**
     * @param callable $callback
     */
    abstract public function transaction(callable $callback);
}
